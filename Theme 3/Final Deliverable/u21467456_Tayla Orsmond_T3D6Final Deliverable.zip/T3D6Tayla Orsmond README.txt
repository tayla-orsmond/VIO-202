Tayla Orsmond u21467456
Vio motion comic vvv
https://vio-motion-comic.netlify.app/

If you are going to host this project on your own local server, please ensure there are no CORS errors while doing so (if panels look missing / unplayable, this may be the case although it is unlikely to happen).